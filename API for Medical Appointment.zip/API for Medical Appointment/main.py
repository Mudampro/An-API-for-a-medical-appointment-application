from fastapi import FastAPI

from routers.patient import patient_router
from routers.doctor import doctor_router
from routers.appointment import appointment_router

app = FastAPI()

app.include_router(patient_router, prefix="/Patients", tags=["Patient"])
app.include_router(doctor_router, prefix="/Doctors", tags=["Doctor"])
app.include_router(appointment_router, prefix="/Appointmens", tags=["Appointment"])




@app.get("/")
def Home():
    return {"Message": "Welcome to Backend Python second semester examination Project, By Sunday Moses"}