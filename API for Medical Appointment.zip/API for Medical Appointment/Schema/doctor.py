from pydantic import BaseModel

class Doctor(BaseModel):
    id: int
    name: str
    specialization: str
    Phone: str
    is_available: bool = True

class DoctorCreate(BaseModel):
    name: str
    specialization: str
    Phone: str
    is_available: bool = True

doctors: dict[int, bool] ={
    1: Doctor(
        id=1, name="Martins Iwao", specialization="Oncologist", Phone="09033", is_available=True
        ),
    2: Doctor(
        id=2, name="Seth Bukuda", specialization="Cardiologist", Phone="08064",is_available=True
        ),
    3: Doctor(
        id=3, name="Grace Angaye", specialization="Orthopedic Surgeon", Phone="09022", is_available=True
        )
}