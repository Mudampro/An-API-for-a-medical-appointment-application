from pydantic import BaseModel


class Appointment(BaseModel):
    id: int
    patient_id: int
    doctor_id: int
    date: str

class AppointmentCreate(BaseModel):
    patient_id: int
    doctor_id: int
    date: str

appointments: list[Appointment] = []


