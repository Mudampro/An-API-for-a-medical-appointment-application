from pydantic import BaseModel

class Patient(BaseModel):
    id: int
    name: str
    age: int
    sex: str
    weight: float
    height: float
    phone: str

class PatientCreate(BaseModel):
    name: str
    age: int
    sex: str
    weight: float
    height: float
    phone: str


patients: dict[int, Patient] = {
    1: Patient(
        id=1, name="Amos Jide", age=23, sex="Male", weight=54.6, height=5.7, phone="09027"
        ),
    2: Patient(
        id=2, name="Bode Thomas", age=31, sex="Male", weight=61.3, height=4.5, phone="08034"
        ),
    3: Patient(
        id=3, name="Wilfred Anna", age=22, sex="Female", weight=44.2, height=4.9, phone="07060"
        )
}