from fastapi import HTTPException


from Schema.appointment import Appointment, AppointmentCreate, appointments
from Schema.patient import patients
from Schema.doctor import doctors



class AppointmentService:

    @staticmethod
    def create_appointment(payload: AppointmentCreate):
        patient_id = payload.patient_id
        doctor_id = payload.doctor_id
        appointment_date = payload.date
        if patient_id not in patients:
            raise HTTPException(status_code=404, detail="Patient not found")
        if doctor_id not in doctors:
            raise HTTPException(status_code=404, detail="Doctor not found")
        if not doctors[doctor_id].is_available:
            raise HTTPException(status_code=400, detail="Doctor currently unavailable")
        
        appointment_id = len(appointments) + 1
        appointments.append(Appointment(
            id=appointment_id,
            patient_id= patient_id,
            doctor_id=doctor_id,
            date = appointment_date
        ))
        doctors[doctor_id].is_available = False
        return {"Message": "Appointment created successfully", "data": appointment_id}
    
    @staticmethod
    def complete_an_existing_appointment(appointment_id: int):
        for appointment in appointments:
            if appointment.id == appointment_id:
                doctor_id = appointment.doctor_id
                doctors[doctor_id].is_available = True
                appointments.remove(appointment)
                return {"Message": "Appointment completed successfully"}
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    @staticmethod
    def cancel_an_existing_appointment(appointment_id: int):
        for appointment in appointments:
            if appointment.id == appointment_id:
                doctor_id = appointment_id
                doctors[doctor_id].is_available = True
                appointments.remove(appointment)
                return {"Message": "Appointment cancel successfully"}
        raise HTTPException(status_code=404, detail="Appointment not found")