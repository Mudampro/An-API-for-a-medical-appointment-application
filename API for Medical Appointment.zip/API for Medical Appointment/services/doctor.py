from fastapi import HTTPException

from Schema.doctor import Doctor, DoctorCreate, doctors


class DoctorService:

    @staticmethod
    def create_doctor(doctor_data:DoctorCreate):
        id = len(doctors) + 1
        doctor = Doctor(
            id=id,
            **doctor_data.model_dump()
        )
        doctors[id] = doctor
        return doctor

    @staticmethod
    def parse_doctors(doctor_data):
        data = []
        for doct in doctor_data:
            data.append(doctors[doct])
        return data
    
    @staticmethod
    def get_doctor_by_id(doctor_id):
        doctor = doctors.get(doctor_id)
        if not doctor:
            raise HTTPException(detail='Doctor not found.', status_code=404)
        return doctor
    
    @staticmethod
    def edit_doctor(doctor_id: int, payload: DoctorCreate):
        if doctor_id not in doctors:
            raise HTTPException(status_code=404, detail="Doctor not found")
        doctor = doctors[doctor_id]
        doctor.name = payload.name
        doctor.specialization = payload.specialization
        doctor.Phone =payload.Phone
        doctor.is_available = payload.is_available
        return doctor
    
    @staticmethod
    def delete_doctor(doctor_id:int):
        doctor = doctors.get(doctor_id)
        if not doctor:
            raise HTTPException(detail= "Doctor not found", status_code=404)
        del doctors[doctor_id]

    @staticmethod
    def set_doctor_availability_status(doctor_id: int, is_available: bool):
        if doctor_id in doctors:
            doctors[doctor_id].is_available = is_available
            return {"Message": f"Doctor with ID {doctor_id} availability stutaus updated"}
        return HTTPException(status_code=404, detail="Doctor not found")