from fastapi import APIRouter

from Schema.doctor import DoctorCreate, doctors
from services.doctor import DoctorService

doctor_router = APIRouter()


@doctor_router.post("/", status_code=201)
def create_doctor(payload: DoctorCreate):
 data = DoctorService.create_doctor(payload)
 return {"Messgae": "Doctor created Successfully", "data": data}

@doctor_router.get("/", status_code=200)
def list_doctors():
    data = DoctorService.parse_doctors(doctor_data=doctors)
    return {"Message": "Success", "data": data}

@doctor_router.get("/{doctor_id}", status_code=200)
def get_doctor_by_id(doctor_id:int):
    data = DoctorService.get_doctor_by_id(doctor_id)
    return {"Message": "Success", "data": data}

@doctor_router.put("/{doctor_id}", status_code=200)
def edit_doctor(doctor_id: int, payload:DoctorCreate):
   data = DoctorService.edit_doctor(doctor_id, payload)
   return {"Message": "Doctor edited successfully", "data": data}

@doctor_router.delete("/{doctor_id}", status_code=200)
def delete_doctor(doctor_id: int):
   DoctorService.delete_doctor(doctor_id)
   return f"Doctor with ID number {doctor_id} has been deleted successfuly"

@doctor_router.put("/", status_code=200)
def set_doctor_availability_status(doctor_id: int, is_available: bool):
   data= DoctorService.set_doctor_availability_status(doctor_id, is_available)
   return data