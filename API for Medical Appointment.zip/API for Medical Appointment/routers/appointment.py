from fastapi import APIRouter


from Schema.appointment import AppointmentCreate, appointments
from services.appointment import AppointmentService


appointment_router = APIRouter()

@appointment_router.post("/", status_code=201)
def create_appointment(payload: AppointmentCreate):
    data = AppointmentService.create_appointment(payload)
    return data

@appointment_router.get("/", status_code=200)
def get_all_appointments():
    return appointments

@appointment_router.put("/{appointment_id}", status_code=200)
def complete_an_appointment(appointment_id: int):
    data = AppointmentService.complete_an_existing_appointment(appointment_id)
    return {"Message": "Success", "data": data}

@appointment_router.delete("/{appointment_id}", status_code=200)
def cancel_an_appointment(appointment_id: int):
    data = AppointmentService.cancel_an_existing_appointment(appointment_id)
    return {"Message": "Success", "data": data}