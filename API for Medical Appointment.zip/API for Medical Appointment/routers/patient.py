from fastapi import APIRouter

from Schema.patient import PatientCreate, patients
from services.patient import PatientService


patient_router = APIRouter()


@patient_router.post("/", status_code=201)
def create_patient(payload: PatientCreate):
 data = PatientService.create_patient(payload)
 return {"Messgae": "patient created Successfully", "data": data}

@patient_router.get("/", status_code=200)
def list_patients():
    data = PatientService.parse_patients(patient_data=patients)
    return {"Message": "Success", "data": data}

@patient_router.get("/{patient_id}", status_code=200)
def get_patient_by_id(patient_id:int):
    data = PatientService.get_patient_by_id(patient_id)
    return {"Message": "Success", "data": data}

@patient_router.put("/{patient_id}", status_code=200)
def edit_patient(patient_id: int, payload:PatientCreate):
   data = PatientService.edit_patient(patient_id, payload)
   return {"Message": "Patient edited successfully", "data": data}

@patient_router.delete("/{patient_id}", status_code=200)
def delete_patient(patient_id: int):
   PatientService.delete_patient(patient_id)
   return f"Patient with ID number {patient_id} has been deleted successfuly"